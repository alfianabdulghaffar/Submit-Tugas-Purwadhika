if __name__ == '__main__':
    apel = input("Silahkan masukkan jumlah apel: ")
    jeruk = input("Silahkan masukkan jumlah jeruk: ")
    anggur = input("Silahkan masukkan jumlah anggur: ")

    hargaApel = int (apel)*10000
    hargaJeruk = int (jeruk)*15000
    hargaAnggur = int (anggur)*20000

    print ('Detail Belanja :')
    print ('Harga Semua Buah Apel :', hargaApel)
    print ('Harga Semua Buah Jeruk :', hargaJeruk)
    print ('Harga Semua Buah Anggur :', hargaAnggur)
    print ('Total Belanja Anda :', hargaApel+hargaJeruk+hargaAnggur)
