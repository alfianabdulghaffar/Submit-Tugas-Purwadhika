if __name__ == '__main__':
   # A = Kecepatan Mobil A (60 km/jam)
   # B = Kecepatan Mobil B (40 km/jam)
   # C = Jarak
   # X = Waktu Tabrakan (dalam jam)
   # (60X)*40 =(120-60X)*60
   # X = ((120*60)-(60*60)X))/(60*40)
   # X (40+60)=120
   # X = 120/(40+60)
   # X = C / (A+B)

   A = 60 
   B = 40
   C = 120
   X = C / (A+B)
   jamBerangkat = 9
   totalMenitTabrakan = X*60
   jamTabrakan=totalMenitTabrakan//60
   menitTabrakan = totalMenitTabrakan % 60

   print ('mobil akan bertabrakan pada jam', int(jamBerangkat+jamTabrakan),'lebih',int(menitTabrakan),'menit')
   

   

