if __name__ == '__main__':
    x, y, z = 4, 3, 2
    w = (x+(y*z)/(x*y))**z
    print (w)